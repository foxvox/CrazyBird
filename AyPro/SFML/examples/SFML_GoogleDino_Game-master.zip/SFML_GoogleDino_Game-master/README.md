# SFML_GoogleDino_Game
C++ SFML google dinosaurs


YouTube : https://youtu.be/W9SfkPTn5BU   
Blog : https://blockdmask.tistory.com/371
